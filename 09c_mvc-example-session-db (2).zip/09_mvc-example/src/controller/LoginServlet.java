package controller;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



import dao.SystemDao;
import dao.StudentDao;
import controller.*;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SystemDao dao;
	private StudentDao studentDao;
	
	public LoginServlet() {
	        super();
	        dao=new SystemDao();
	        studentDao = new StudentDao();
	    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String usernamevalidation=dao.loginusernameCheck(username);
		
		if (usernamevalidation!=username) 
		{
			request.setAttribute("message", usernamevalidation);
			request.setAttribute("username", username);
			RequestDispatcher view = request.getRequestDispatcher("/index.jsp");
			view.forward(request, response);
		}else 
		{
			password=password+dao.getSalt(username);
			MessageDigest digest;
			try {
					digest = MessageDigest.getInstance("SHA-1");
					byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
					password=dao.bytesToHex(encodedhash);
					String passwordvalidation=dao.passwordCheck(username, password);
					
					if (passwordvalidation=="You logged in!") 
						
					{
						//System.out.println("You logged in!");
						String role=dao.getRole(username);
						//System.out.println("ROLE ====="+role);
						HttpSession session = request.getSession(true);
						synchronized(session) 
						{	
							session.setAttribute("username", username);
							session.setAttribute("role", role);
							session.setAttribute("registrationnumber", studentDao.getStudentRegistrationNumber(username));
														
														
							if (role.equals("student")) 
							{
								System.out.println("INSIDE role STUDENT !");
								//request.setAttribute("username", username);
								//request.setAttribute("role", role);
								//request.setAttribute("registrationnumber", studentDao.getStudentRegistrationNumber(username));
								System.out.println("registrationNUMBER="+studentDao.getStudentRegistrationNumber(username));
								RequestDispatcher view = request.getRequestDispatcher("/student.jsp");
								view.forward(request, response);
							}
							else if (role.equals("professor")) 
							{
								//TODO
							
							}
							else 
							{
								session.setAttribute("role", "secretary");
								//TODO
							}
						}
					}									
					else 
					{
						request.setAttribute("message", passwordvalidation);
						RequestDispatcher view = request.getRequestDispatcher("/index.jsp");
						view.forward(request, response);
					}
				} 
				catch (NoSuchAlgorithmException e) 
				{
					e.printStackTrace();
				}
		}	
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
}



